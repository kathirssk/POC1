
 mongoUrl="mongodb://172.24.150.53:27017/pocdemo";
 userControl="/usercontroller";
 router="/route";
 login="/login";
 customFetch="/customfetch";
// const addUserDetails=